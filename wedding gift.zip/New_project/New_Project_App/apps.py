from django.apps import AppConfig


class NewProjectAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'New_Project_App'
