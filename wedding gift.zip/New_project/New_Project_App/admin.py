from django.contrib import admin
from .models import Users_Data

# Register your models here.
admin.site.register(Users_Data)